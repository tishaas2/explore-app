from django.db import models

class Place(models.Model):
    city = models.CharField(max_length=100)
    country = models.CharField(max_length=100)
    description = models.TextField()
    image_url = models.URLField()

    def __str__(self):
        return self.city
