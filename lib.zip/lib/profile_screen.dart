import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';

class ProfileScreen extends StatelessWidget {
  final String userName;
  final String profilePic;
  final int favoriteCount;
  final int visitedCount;
  final int toursTaken;

  const ProfileScreen({
    Key? key,
    required this.userName,
    required this.profilePic,
    required this.favoriteCount,
    required this.visitedCount,
    required this.toursTaken,
  }) : super(key: key);

  String getFormattedUserName() {
    String formattedName = userName.split('@')[0];
    formattedName = formattedName.replaceAll(RegExp(r'\d'), '') // Remove numbers
        .replaceAll(".", " ") // Replace dots with spaces
        .trim();

    return formattedName.split(' ').map((word) {
      if (word.isNotEmpty) {
        return word[0].toUpperCase() + word.substring(1);
      }
      return '';
    }).join(' ').trim();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Profile & Settings",
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        actions: [
          TextButton(
            onPressed: () {
              _showLogoutDialog(context);
            },
            child: const Text("Log out",
                style: TextStyle(color: Colors.black, fontSize: 16)),
          ),
        ],
        backgroundColor: Colors.white,
        elevation: 1,
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildProfileHeader(),
            const Divider(thickness: 1),
            _SettingsSection(),
          ],
        ),
      ),
    );
  }

  void _showLogoutDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Log out"),
        content: const Text("Are you sure you want to log out?"),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context), // Close the dialog
            child: const Text("Cancel"),
          ),
          TextButton(
            onPressed: () async {
              Navigator.pop(context); // Close the dialog before logging out

              try {
                await FirebaseAuth.instance.signOut(); // Firebase logout
                _navigateToLoginScreen(context); // Redirect to login screen
              } catch (e) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text("Error logging out: ${e.toString()}")),
                );
              }
            },
            child: const Text("Log out", style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  void _navigateToLoginScreen(BuildContext context) {
    Navigator.pushNamedAndRemoveUntil(context, '/login', (route) => false);
  }

  Widget _buildProfileHeader() {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Row(
        children: [
          CircleAvatar(
            radius: 40,
            backgroundImage: profilePic.isNotEmpty
                ? (profilePic.startsWith("http")
                ? NetworkImage(profilePic) as ImageProvider
                : AssetImage(profilePic))
                : const AssetImage("assets/images/profile.png"),
          ),
          const SizedBox(width: 16),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                getFormattedUserName(),
                style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 6),
              _buildInfoRow(Icons.check_circle, Colors.green, "Visited places: $visitedCount"),
              _buildInfoRow(Icons.favorite, Colors.red, "Favorite places: $favoriteCount"),
              _buildInfoRow(Icons.tour, Colors.blue, "Tours taken: $toursTaken"),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildInfoRow(IconData icon, Color color, String text) {
    return Row(
      children: [
        Icon(icon, color: color, size: 16),
        const SizedBox(width: 6),
        Text(text, style: TextStyle(color: color, fontSize: 14)),
      ],
    );
  }
}

class _SettingsSection extends StatefulWidget {
  @override
  _SettingsSectionState createState() => _SettingsSectionState();
}

class _SettingsSectionState extends State<_SettingsSection> {
  bool isSettingsExpanded = false;
  String selectedTheme = "System settings";

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        ListTile(
          leading: const Icon(Icons.settings),
          title: const Text("Settings", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          trailing: Icon(isSettingsExpanded ? Icons.expand_less : Icons.expand_more),
          onTap: () {
            setState(() {
              isSettingsExpanded = !isSettingsExpanded;
            });
          },
        ),
        if (isSettingsExpanded) ...[
          _settingsOption(Icons.language, "Preferred languages"),
          _dropdownThemeOption(),
          _settingsOption(Icons.thermostat, "Temperature"),
          _settingsOption(Icons.map, "Distance", trailingText: "km"),
          const Divider(thickness: 1),
        ],
        _settingsOption(Icons.restore, "Restore purchases"),
        _settingsOption(Icons.feedback, "Share feedback"),
        _settingsOption(Icons.info, "About application"),
        _settingsOption(Icons.delete, "Delete account", color: Colors.red),
      ],
    );
  }

  Widget _settingsOption(IconData icon, String text, {Color color = Colors.black, String? trailingText}) {
    return ListTile(
      leading: Icon(icon, color: color),
      title: Text(text, style: TextStyle(color: color, fontSize: 16)),
      trailing: trailingText != null
          ? Text(trailingText, style: const TextStyle(fontSize: 16))
          : const Icon(Icons.chevron_right, color: Colors.grey),
      onTap: () {},
    );
  }

  Widget _dropdownThemeOption() {
    return ListTile(
      leading: const Icon(Icons.palette),
      title: const Text("Application theme", style: TextStyle(fontSize: 16)),
      trailing: Text(selectedTheme, style: const TextStyle(fontSize: 16, color: Colors.grey)),
      onTap: () async {
        String? chosenOption = await showMenu<String>(
          context: context,
          position: RelativeRect.fromLTRB(100, 400, 100, 100),
          items: ["Dark", "Light", "System settings"].map((option) {
            return PopupMenuItem<String>(
              value: option,
              child: Text(option),
            );
          }).toList(),
        );

        if (chosenOption != null) {
          setState(() {
            selectedTheme = chosenOption;
          });
        }
      },
    );
  }
}
