import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiService {
  static const String _clientId = "RZy3xN12PVIrpeQpKWqQGu5keRbPiSAH"; // Replace with your actual Client ID
  static const String _clientSecret = "tr8GfZMKiPEybb5I"; // Replace with your actual Secret
  static const String _tokenUrl = "https://test.api.amadeus.com/v1/security/oauth2/CCWKhRqivfP086adXGQmr0eMiqkl";

  static Future<String> getAccessToken() async {
    final response = await http.post(
      Uri.parse(_tokenUrl),
      headers: {"Content-Type": "application/x-www-form-urlencoded"},
      body: {
        "grant_type": "client_credentials",
        "client_id": _clientId,
        "client_secret": _clientSecret,
      },
    );

    if (response.statusCode == 200) {
      var data = jsonDecode(response.body);
      return data["access_token"]; // ✅ Return token
    } else {
      print("❌ Failed to retrieve access token: ${response.body}");
      throw Exception("Failed to retrieve access token");
    }
  }
}