import 'package:cloud_firestore/cloud_firestore.dart';

void addTravelPlaces() async {
  FirebaseFirestore firestore = FirebaseFirestore.instance;

  List<Map<String, dynamic>> places = [
    {
      "city": "Kashmir",
      "country": "India",
      "imagePath": "assets/images/gulmarg.jpg",
      "description": "Kashmir, often referred to as 'Paradise on Earth,' is a breathtaking region known for its stunning landscapes, serene lakes, snow-capped mountains, and rich cultural heritage. The valleys of Kashmir, such as Gulmarg, Pahalgam, and Sonmarg, offer mesmerizing views and adventure activities like skiing, trekking, and river rafting. Dal Lake in Srinagar, famous for its Shikara rides and houseboats, attracts thousands of tourists. The region is also renowned for its Pashmina shawls, Kashmiri carpets, saffron, and dry fruits."

    },
    {
      "city": "Himachal Pradesh",
      "country": "India",
      "imagePath": "assets/images/kullu.jpg",
      "description": "Himachal Pradesh is known for its picturesque hill stations, adventure tourism, and rich spiritual heritage. Popular destinations include Shimla (the Queen of Hills), Manali, Dharamshala, Dalhousie, and Kasol. Himachal is a paradise for adventure lovers, offering activities like trekking in Triund, paragliding in Bir Billing, and river rafting in Kullu. The local Himachali cuisine includes dishes such as Sidu, Chana Madra, Babru, and Dham (a festive meal)."    },
    {
      "city": "Kerala",
      "country": "India",
      "imagePath": "assets/images/alleppey.jpg",
      "description": "Kerala, also known as 'God's Own Country,' is famous for its backwaters, Ayurvedic treatments, lush greenery, and vibrant culture. The Alleppey backwaters offer houseboat experiences, while Munnar’s tea plantations, Wayanad’s forests, and Kovalam’s beaches add to its charm. Kerala’s culture is deeply rooted in its classical dance forms like Kathakali and Mohiniyattam, and grand festivals such as Onam and Thrissur Pooram."    },
    {
      "city": "Rajasthan",
      "country": "India",
      "imagePath": "assets/images/jaipur.jpg",
      "description": "Rajasthan, the land of royalty and deserts, is famous for its majestic forts, palaces, and rich history. Cities like Jaipur (Pink City), Udaipur (City of Lakes), Jodhpur (Blue City), Jaisalmer (Golden City), and Bikaner showcase magnificent forts like Amer Fort, Mehrangarh Fort, and Jaisalmer Fort. The Thar Desert offers unique experiences like camel safaris, desert camping, and folk performances of Ghoomar and Kalbelia dances. "    },
    {
      "city": "Goa",
      "country": "India",
      "imagePath": "assets/images/goa.jpg",
      "description": "Goa, India’s party capital, is best known for its beautiful beaches, vibrant nightlife, and Portuguese influence. Popular beaches like Baga, Anjuna, Calangute, and Palolem offer water sports like jet skiing, scuba diving, and parasailing. Goa’s rich history is reflected in Old Goa’s churches, forts like Aguada and Chapora, and traditional Goan houses. The annual Goa Carnival and Sunburn Festival attract global tourists. Goan cuisine is a mix of Indian and Portuguese flavors, with dishes like Goan Fish Curry, Vindaloo, Bebinca (a layered dessert), and Feni (a local cashew-based drink). "
    },
    {
      "city": "Delhi",
      "country": "India",
      "imagePath": "assets/images/delhi.jpg",
      "description": "Delhi, the heart of India, is a city that perfectly blends history, culture, and modernity. The city is home to historic monuments like Red Fort, India Gate, Humayun’s Tomb, and Qutub Minar, as well as modern attractions like Connaught Place, Lotus Temple, and Akshardham Temple. Chandni Chowk is a paradise for food lovers, offering street foods like Chole Bhature, Paranthas, Butter Chicken, and Momos. The city hosts numerous festivals, including Diwali, Holi, Eid, and Republic Day celebrations at Rajpath. Delhi is also known for its shopping streets like Sarojini Nagar, Lajpat Nagar, and Dilli Haat, where one can find everything from clothes to handicrafts."
    },
    {
      "city": "Mumbai",
      "country": "India",
      "imagePath": "assets/images/mumbai.jpg",
      "description": "Mumbai, the City of Dreams, is India's financial capital and the home of Bollywood. It is famous for Marine Drive, Gateway of India, Elephanta Caves, Juhu Beach, and the iconic Bandra-Worli Sea Link. The city's fast-paced life is balanced by its vibrant culture, with grand celebrations of Ganesh Chaturthi, Navratri, and Christmas. The food scene in Mumbai is diverse, with street food like Vada Pav, Pav Bhaji, Misal Pav, and Bhel Puri being local favorites. The city’s nightlife, with its high-end clubs, rooftop restaurants, and Bollywood parties, makes it a hub for entertainment. Mumbai also has a rich colonial past, evident in heritage buildings like Chhatrapati Shivaji Maharaj Terminus (CST) and the Taj Mahal Palace Hotel."
    },

  ];

  for (var place in places) {
    await firestore.collection("travel_places").add(place);
  }

  print("✅ All places added to Firestore!");
}
