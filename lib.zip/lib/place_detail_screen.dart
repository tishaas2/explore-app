import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';

class PlaceDetailScreen extends StatefulWidget {
  final String city;
  final String country;
  final String imagePath;
  final String description;

  const PlaceDetailScreen({
    Key? key,
    required this.city,
    required this.country,
    required this.imagePath,
    required this.description,
  }) : super(key: key);

  @override
  _PlaceDetailScreenState createState() => _PlaceDetailScreenState();
}

class _PlaceDetailScreenState extends State<PlaceDetailScreen> {
  final FlutterTts flutterTts = FlutterTts();
  bool isPlaying = false;
  bool isExpanded = false;
  String selectedLanguage = "en-US"; // Default language

  final List<Map<String, String>> languages = [
    {"name": "English", "code": "en-US"},
    {"name": "Hindi", "code": "hi-IN"},
    {"name": "French", "code": "fr-FR"},
    {"name": "Spanish", "code": "es-ES"},
  ];

  Future<void> _speak() async {
    await flutterTts.setLanguage(selectedLanguage);
    await flutterTts.setPitch(1.0);
    await flutterTts.speak(widget.description);
    setState(() => isPlaying = true);
  }

  Future<void> _stop() async {
    await flutterTts.stop();
    setState(() => isPlaying = false);
  }

  @override
  void dispose() {
    flutterTts.stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    bool isFirebaseUrl = widget.imagePath.startsWith('http');

    return Scaffold(
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Image and Back Button
            Stack(
              children: [
                isFirebaseUrl
                    ? Image.network(
                  widget.imagePath,
                  width: double.infinity,
                  height: 250,
                  fit: BoxFit.cover,
                  errorBuilder: (context, error, stackTrace) {
                    return Image.asset(
                      'assets/images/${widget.city.toLowerCase()}.jpg',
                      width: double.infinity,
                      height: 250,
                      fit: BoxFit.cover,
                    );
                  },
                )
                    : Image.asset(
                  'assets/images/${widget.city.toLowerCase()}.jpg',
                  width: double.infinity,
                  height: 250,
                  fit: BoxFit.cover,
                ),
                Positioned(
                  top: 10,
                  left: 10,
                  child: IconButton(
                    icon: const Icon(Icons.arrow_back, color: Colors.white),
                    onPressed: () => Navigator.pop(context),
                  ),
                ),
                Positioned(
                  top: 10,
                  right: 10,
                  child: Row(
                    children: [
                      IconButton(
                        icon: const Icon(Icons.favorite_border, color: Colors.white),
                        onPressed: () {}, // Add favorite functionality here
                      ),
                      IconButton(
                        icon: const Icon(Icons.share, color: Colors.white),
                        onPressed: () {}, // Add share functionality here
                      ),
                    ],
                  ),
                ),
              ],
            ),

            // Content Section
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      widget.city,
                      style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                    ),
                    Text(
                      widget.country,
                      style: const TextStyle(fontSize: 16, color: Colors.grey),
                    ),
                    const SizedBox(height: 10),

                    // Description with Read More
                    Text(
                      isExpanded
                          ? widget.description
                          : (widget.description.length > 100
                          ? "${widget.description.substring(0, 100)}..."
                          : widget.description),
                      style: const TextStyle(fontSize: 14, color: Colors.black87),
                    ),
                    if (widget.description.length > 100)
                      TextButton(
                        onPressed: () => setState(() => isExpanded = !isExpanded),
                        child: Text(isExpanded ? "Read Less" : "Read More"),
                      ),

                    const SizedBox(height: 10),

                    // AI Audio Player
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        DropdownButton<String>(
                          value: selectedLanguage,
                          items: languages.map((lang) {
                            return DropdownMenuItem(
                              value: lang["code"],
                              child: Text(lang["name"]!),
                            );
                          }).toList(),
                          onChanged: (value) {
                            setState(() => selectedLanguage = value!);
                          },
                        ),
                        IconButton(
                          icon: Icon(
                            isPlaying ? Icons.pause_circle_filled : Icons.play_circle_fill,
                            size: 40,
                          ),
                          onPressed: isPlaying ? _stop : _speak,
                        ),
                      ],
                    ),

                    const SizedBox(height: 10),

                    // Map Button
                    ElevatedButton.icon(
                      onPressed: () {
                        // Navigate to map screen
                      },
                      icon: const Icon(Icons.map),
                      label: const Text("Map"),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.blue,
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
