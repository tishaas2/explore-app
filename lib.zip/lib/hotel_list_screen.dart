import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';

class HotelListScreen extends StatefulWidget {
  final String city;
  final DateTime checkIn;
  final DateTime checkOut;
  final int guests;

  HotelListScreen({
    required this.city,
    required this.checkIn,
    required this.checkOut,
    required this.guests, required String location,
  });

  @override
  _HotelListScreenState createState() => _HotelListScreenState();
}

class _HotelListScreenState extends State<HotelListScreen> {
  List<dynamic> hotels = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    fetchHotels();
  }
  Future<String> getAccessToken() async {
    const String tokenUrl = "https://test.api.amadeus.com/v1/security/oauth2/token";
    const String clientId = "RZy3xN12PVIrpeQpKWqQGu5keRbPiSAH";
    const String clientSecret = "tr8GfZMKiPEybb5I";

    final response = await http.post(
      Uri.parse(tokenUrl),
      headers: {"Content-Type": "application/x-www-form-urlencoded"},
      body: {
        "grant_type": "client_credentials",
        "client_id": clientId,
        "client_secret": clientSecret,
      },
    );

    print("🔹 Token Response: ${response.body}");

    if (response.statusCode == 200) {
      var data = jsonDecode(response.body);
      return data["access_token"];
    } else {
      throw Exception("❌ Failed to retrieve access token: ${response.body}");
    }
  }

  Future<void> fetchHotels() async {
    setState(() {
      isLoading = true;
    });

    try {
      String accessToken = await getAccessToken();
      final String formattedCheckIn = DateFormat('yyyy-MM-dd').format(widget.checkIn);
      final String formattedCheckOut = DateFormat('yyyy-MM-dd').format(widget.checkOut);
      final String apiUrl = "https://test.api.amadeus.com/v3/shopping/hotel-offers";

      final String cityCode = widget.city.toUpperCase(); // Use IATA code!

      final uri = Uri.parse(
          "$apiUrl"
              "?cityCode=$cityCode"
              "&checkInDate=$formattedCheckIn"
              "&checkOutDate=$formattedCheckOut"
              "&adults=${widget.guests}"
              "&roomQuantity=1"
              "&priceRange=4000-8000"
              "&currency=INR"
              "&paymentPolicy=NONE"
              "&boardType=ALL_INCLUSIVE"
              "&includeClosed=false"
              "&bestRateOnly=true"
              "&lang=en"
              "&countryOfResidence=IN"
      );


      final response = await http.get(uri, headers: {
        "Authorization": "Bearer $accessToken",
      }).timeout(Duration(seconds: 10));

      print("🔹 Hotel API Response: ${response.body}");

      if (response.statusCode == 200) {
        final decoded = jsonDecode(response.body);
        setState(() {
          hotels = decoded['data'];
        });
      } else {
        print("❌ API Error: ${response.body}");
      }
    } catch (e) {
      print("🔥 Error fetching hotels: $e");
    } finally {
      setState(() {
        isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Hotels in ${widget.city}")),
      body: isLoading
          ? Center(child: CircularProgressIndicator())
          : hotels.isEmpty
          ? Center(child: Text("No hotels found"))
          : ListView.builder(
        itemCount: hotels.length,
        itemBuilder: (context, index) {
          var hotel = hotels[index];
          var hotelInfo = hotel['hotel'];
          var offer = hotel['offers'][0];

          return Card(
            child: ListTile(
              leading: Icon(Icons.hotel, size: 40, color: Colors.blue),
              title: Text(hotelInfo['name'] ?? "Hotel Name"),
              subtitle: Text("₹${offer['price']['total']} per night"),
            ),
          );
        },

      ),
    );
  }
}
