import 'package:flutter/material.dart';

class SearchScreen extends StatefulWidget {
  final List<Map<String, String>> places;

  const SearchScreen({Key? key, required this.places}) : super(key: key);

  @override
  _SearchScreenState createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  TextEditingController _searchController = TextEditingController();
  List<Map<String, String>> _filteredPlaces = [];

  @override
  void initState() {
    super.initState();
    _filteredPlaces = widget.places;
  }

  void _filterPlaces(String query) {
    setState(() {
      _filteredPlaces = widget.places
          .where((place) => place["city"]!.toLowerCase().contains(query.toLowerCase()))
          .toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: TextField(
          controller: _searchController,
          onChanged: _filterPlaces,
          decoration: InputDecoration(
            hintText: "Search places...",
            border: InputBorder.none,
          ),
          style: TextStyle(color: Colors.white, fontSize: 18),
        ),
        backgroundColor: Colors.blue,
      ),
      body: ListView.builder(
        itemCount: _filteredPlaces.length,
        itemBuilder: (context, index) {
          final place = _filteredPlaces[index];
          return ListTile(
            leading: Image.asset(place['imagePath']!, width: 50, height: 50, fit: BoxFit.cover),
            title: Text(place['city']!, style: TextStyle(fontWeight: FontWeight.bold)),
            subtitle: Text(place['country']!),
            onTap: () {
              Navigator.pop(context, place);
            },
          );
        },
      ),
    );
  }
}