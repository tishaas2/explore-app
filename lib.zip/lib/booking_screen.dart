import 'package:flutter/material.dart';

class BookingScreen extends StatelessWidget {
  final Map<String, dynamic> package;

  const BookingScreen({Key? key, required this.package}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Payment')),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          children: [
            Text("Package: ${package['destination']}", style: const TextStyle(fontSize: 18)),
            Text("Price: ₹${package['price']}", style: const TextStyle(fontSize: 16)),
            const SizedBox(height: 20),
            const Text("Choose a Payment Method", style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                // Simulate payment success
                showDialog(
                  context: context,
                  builder: (_) => AlertDialog(
                    title: const Text("Success"),
                    content: const Text("Your package was booked successfully!"),
                    actions: [
                      TextButton(
                        onPressed: () => Navigator.popUntil(context, (route) => route.isFirst),
                        child: const Text("OK"),
                      ),
                    ],
                  ),
                );
              },
              child: const Text("Pay with Card / UPI"),
            ),
          ],
        ),
      ),
    );
  }
}
