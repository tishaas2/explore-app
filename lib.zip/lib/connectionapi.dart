import 'dart:convert';
import 'package:http/http.dart' as http;

Future<List<dynamic>> fetchUsers() async {
  final response = await http.get(Uri.parse('http://127.0.0.1:8000/api/users/'));

  if (response.statusCode == 200) {
    return jsonDecode(response.body);
  } else {
    throw Exception('Failed to load users');
  }
}

Future<void> createUser(String name, String email, int age) async {
  final response = await http.post(
    Uri.parse('http://127.0.0.1:8000/api/users/'),
    headers: {'Content-Type': 'application/json'},
    body: jsonEncode({'name': name, 'email': email, 'age': age}),
  );

  if (response.statusCode == 201) {
    print('User created successfully');
  } else {
    throw Exception('Failed to create user');
  }
}

