import 'package:flutter/material.dart';

class TrainListScreen extends StatelessWidget {
  final List<Map<String, String>> trains = [
    {'name': 'Rajdhani Express', 'route': 'Delhi - Kolkata'},
    {'name': 'Shatabdi Express', 'route': 'Mumbai - Pune'}
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Trains List')),
      body: ListView.builder(
        itemCount: trains.length,
        itemBuilder: (context, index) {
          return Card(
            margin: EdgeInsets.all(10),
            child: ListTile(
              title: Text(trains[index]['name']!),
              subtitle: Text(trains[index]['route']!),
            ),
          );
        },
      ),
    );
  }
}
