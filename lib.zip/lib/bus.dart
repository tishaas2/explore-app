import 'package:flutter/material.dart';

class BusListScreen extends StatelessWidget {
  final List<Map<String, String>> buses = [
    {'name': 'Volvo AC Bus', 'route': 'Chennai - Hyderabad'},
    {'name': 'State Transport', 'route': 'Bangalore - Goa'}
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(title: Text('Buses List')),
        body: ListView.builder(
            itemCount: buses.length,
            itemBuilder: (context, index) {
              return Card(
                margin: EdgeInsets.all(10),
                child: ListTile(
                  title: Text(buses[index]['name']!),
                  subtitle: Text(buses[index]['route']!),
                ),
              );
            },
            ),
        );
  }
}