import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'firebase_options.dart';
import 'welcome.dart';
import 'signup.dart';
import 'login.dart';
import 'homescreen.dart';
import 'map_screen.dart';
import 'package:geolocator/geolocator.dart'; // Added Geolocator import
import 'hotel_list_screen.dart';
import 'hotel_search_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  // Geolocator Initialization
  await _initializeGeolocator();

  runApp(const MyApp());
}

// Geolocator Permission Handling
Future<void> _initializeGeolocator() async {
  bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
  if (!serviceEnabled) {
    print('❌ Location services are disabled.');
    return;
  }

  LocationPermission permission = await Geolocator.checkPermission();
  if (permission == LocationPermission.denied) {
    permission = await Geolocator.requestPermission();
    if (permission == LocationPermission.denied) {
      print('⚠️ Location permissions are denied.');
      return;
    }
  }

  if (permission == LocationPermission.deniedForever) {
    print('🚫 Location permissions are permanently denied.');
    return;
  }

  print('✅ Geolocator initialized successfully.');
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: const AuthCheck(), // This is the starting screen
      routes: {
        '/signup': (context) => const RegistrationPage(),
        '/login': (context) => const LoginPage(),
        '/hotelSearch': (context) => HotelSearchScreen(), // 👈 Add this

      },
    );
  }
}

class AuthCheck extends StatelessWidget {
  const AuthCheck({super.key});

  Future<Map<String, dynamic>> _fetchUserData(String uid) async {
    try {
      DocumentSnapshot userDoc =
      await FirebaseFirestore.instance.collection('Users').doc(uid).get();
      if (userDoc.exists) {
        return userDoc.data() as Map<String, dynamic>;
      }
    } catch (e) {
      print("🔥 Error fetching user data: $e");
    }
    return {"visitedCount": 0, "toursTaken": 0}; // Default values
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(
            body: Center(child: CircularProgressIndicator()),
          );
        }

        if (snapshot.hasData && snapshot.data != null) {
          return FutureBuilder<Map<String, dynamic>>(
            future: _fetchUserData(snapshot.data!.uid),
            builder: (context, userDataSnapshot) {
              if (userDataSnapshot.connectionState == ConnectionState.waiting) {
                return const Scaffold(
                  body: Center(child: CircularProgressIndicator()),
                );
              }

              var userData = userDataSnapshot.data ?? {};
              return HomeScreen(
                userName: snapshot.data!.email ?? "Guest",
                profilePic: snapshot.data!.photoURL ?? "",
                visitedCount: userData["visitedCount"] ?? 0,
                toursTaken: userData["toursTaken"] ?? 0,
              );
            },
          );
        } else {
          return const WelcomePage();
        }
      },
    );
  }
}
