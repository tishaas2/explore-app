import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import 'search.dart';
import 'place_detail_screen.dart';
import 'profile_screen.dart';
import 'map_screen.dart';
import 'hotel_list_screen.dart';
import 'Taxi.dart';
import 'bus.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';
import 'booking_screen.dart';
import 'tour_packages_screen.dart';

class HomeScreen extends StatefulWidget {
  final String userName;
  final String profilePic;
  final int visitedCount;
  final int toursTaken;

  const HomeScreen({
    Key? key,
    required this.userName,
    required this.profilePic,
    required this.visitedCount,
    required this.toursTaken,
  }) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _selectedIndex = 0;
  String searchQuery = "";
  List<Map<String, String>> favoritePlaces = [];
  Map<String, bool> favoriteStatus = {};
  List<Map<String, String>> firebasePlaces = [];
  List<Map<String, dynamic>> allPackages = [];

  Future<void> fetchTourPackages() async {
    final snapshot = await FirebaseFirestore.instance.collection('tourPackages')
        .get();
    setState(() {
      allPackages = snapshot.docs.map((doc) => doc.data()).toList();
    });
  }


  final List<Map<String, dynamic>> categories = [
    {"name": "Hotel", "icon": Icons.hotel},
    {"name": "Plane", "icon": Icons.flight},
    {"name": "Train", "icon": Icons.train},
    {"name": "Taxi", "icon": Icons.local_taxi},
    {"name": "Bus", "icon": Icons.directions_bus},
    {"name": "Packages", "icon": Icons.card_travel}, // New package option added
  ];

  get imageProvider => null;

  @override
  void initState() {
    super.initState();
    fetchPlacesFromFirestore();
    fetchTourPackages(); // <-- Call it here
  }

  Future<void> fetchPlacesFromFirestore() async {
    final snapshot = await FirebaseFirestore.instance.collection('places')
        .get();
    setState(() {
      firebasePlaces = snapshot.docs.map((doc) {
        final data = doc.data();
        return {
          "city": data["city"]?.toString() ?? "",
          "country": data["country"]?.toString() ?? "",
          "description": data["description"]?.toString() ?? "",
          "imagePath": data["imageUrl"]?.toString() ?? "",
        };
      }).toList();
    });
  }

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  void toggleFavorite(Map<String, String> place) {
    setState(() {
      String city = place['city'] ?? "";
      if (favoriteStatus[city] == true) {
        favoritePlaces.removeWhere((p) => p['city'] == city);
        favoriteStatus[city] = false;
      } else {
        favoritePlaces.add(place);
        favoriteStatus[city] = true;
      }
    });
  }

  String getUserName() {
    return widget.userName.split('@')[0]
        .replaceAll(RegExp(r'[0-9]'), '')
        .replaceAll('.', ' ')
        .split(' ')
        .map((word) =>
    word.isNotEmpty ? word[0].toUpperCase() + word.substring(1) : '')
        .join(' ')
        .trim();
  }

  @override
  Widget build(BuildContext context) {
    List<Widget> screens = [
      buildMainScreen(),
      MapScreen(),
      buildFavoritesScreen(),
      ProfileScreen(
        userName: widget.userName,
        profilePic: widget.profilePic,
        favoriteCount: favoritePlaces.length,
        visitedCount: widget.visitedCount,
        toursTaken: widget.toursTaken,
      ),
    ];

    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(child: screens[_selectedIndex]),
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: "Home"),
          BottomNavigationBarItem(icon: Icon(Icons.map), label: "Map"),
          BottomNavigationBarItem(
              icon: Icon(Icons.favorite), label: "Favorites"),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: "Profile"),
        ],
        currentIndex: _selectedIndex,
        selectedItemColor: Colors.blue,
        unselectedItemColor: Colors.grey,
        onTap: _onItemTapped,
      ),
    );
  }

  Widget buildMainScreen() {
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          buildHeader(),
          buildSearchBar(),
          buildCategoryButtons(),
          const SizedBox(height: 10),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: const Text("Popular Places",
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          ),
          buildPopularPlaces(),
        ],
      ),
    );
  }

  Widget buildFavoritesScreen() {
    return favoritePlaces.isEmpty
        ? const Center(child: Text("No favorites yet."))
        : ListView.builder(
      itemCount: favoritePlaces.length,
      itemBuilder: (context, index) => buildTravelCard(favoritePlaces[index]),
    );
  }

  Widget buildHeader() {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text("Hi, ${getUserName()}", style: const TextStyle(
                    fontSize: 24, fontWeight: FontWeight.bold)),
                const Text("Explore the world",
                    style: TextStyle(fontSize: 14, color: Colors.grey)),
              ],
            ),
          ),
          CircleAvatar(
            radius: 30,
            backgroundImage: widget.profilePic.isNotEmpty
                ? (widget.profilePic.startsWith("http")
                ? NetworkImage(widget.profilePic)
                : AssetImage(widget.profilePic)) as ImageProvider
                : const AssetImage("assets/images/profile.png"),
          ),
        ],
      ),
    );
  }

  Widget buildSearchBar() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0),
      child: TextField(
        decoration: InputDecoration(
          hintText: "Search places...",
          prefixIcon: const Icon(Icons.search),
          border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(16.0),
              borderSide: BorderSide.none),
          filled: true,
          fillColor: Colors.grey[200],
        ),
        onChanged: (value) {
          setState(() {
            searchQuery = value;
          });
        },
      ),
    );
  }

  Widget buildCategoryButtons() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 10),
      child: Wrap(
        spacing: 10,
        runSpacing: 10,
        children: categories.map((category) {
          return GestureDetector(
            onTap: () {
              if (category['name'] == "Hotel") {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => HotelListScreen(
                      city: 'DEL',
                      checkIn: DateTime.now().add(Duration(days: 1)),
                      checkOut: DateTime.now().add(Duration(days: 3)),
                      guests: 2,
                      location: '',
                    ),
                  ),
                );
              } else if (category['name'] == "Packages") {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => TourPackagesScreen(), // 🚫 remove tourPackages
                  ),
                );
              }
              else {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) =>
                        TransportListScreen(category['name']),
                  ),
                );
              }
            },
            child: Chip(
              avatar: Icon(category["icon"], size: 18),
              label: Text(category["name"]),
              backgroundColor: Colors.blue[50],
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget buildPopularPlaces() {
    final filteredPlaces = firebasePlaces.where((place) {
      return place["city"]!.toLowerCase().contains(searchQuery.toLowerCase()) ||
          place["country"]!.toLowerCase().contains(searchQuery.toLowerCase());
    }).toList();

    return SizedBox(
      height: 250,
      child: filteredPlaces.isEmpty
          ? const Center(
          child: Text("No places found",
              style: TextStyle(fontSize: 16, color: Colors.grey)))
          : ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: filteredPlaces.length,
        itemBuilder: (context, index) =>
            buildTravelCard(filteredPlaces[index]),
      ),
    );
  }

  Widget buildTravelCard(Map<String, String> place) {
    final String city = place['city']!;
    final bool isFavorite = favoriteStatus[city] ?? false;

    final String? imagePath = place['imagePath'];
    final bool isFirebaseUrl =
        imagePath != null && imagePath.startsWith('http');

    return Column(
      children: [
        GestureDetector(
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) =>
                    PlaceDetailScreen(
                      city: place['city']!,
                      country: place['country']!,
                      imagePath: imagePath ?? '',
                      description: place['description']!,
                    ),
              ),
            );
          },
          child: Container(
            width: 160,
            height: 220,
            margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 10),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(16),
              boxShadow: const [
                BoxShadow(
                  color: Colors.black26,
                  blurRadius: 5,
                  spreadRadius: 2,
                  offset: Offset(2, 3),
                ),
              ],
            ),
            child: Stack(
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(16),
                  child: Image.asset(
                    'assets/images/${city.toLowerCase()}.jpg',
                    width: 160,
                    height: 220,
                    fit: BoxFit.cover,
                  ),
                ),
                Positioned(
                  top: 10,
                  right: 10,
                  child: GestureDetector(
                    onTap: () => toggleFavorite(place),
                    child: Container(
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.8),
                        shape: BoxShape.circle,
                      ),
                      padding: const EdgeInsets.all(6.0),
                      child: Icon(
                        isFavorite ? Icons.favorite : Icons.favorite_border,
                        color: isFavorite ? Colors.red : Colors.black,
                      ),
                    ),
                  ),
                ),
                Positioned(
                  bottom: 0,
                  child: Container(
                    width: 160,
                    height: 80,
                    decoration: BoxDecoration(
                      borderRadius: const BorderRadius.only(
                        bottomLeft: Radius.circular(16),
                        bottomRight: Radius.circular(16),
                      ),
                      gradient: LinearGradient(
                        begin: Alignment.bottomCenter,
                        end: Alignment.topCenter,
                        colors: [
                          Colors.black.withOpacity(0.8),
                          Colors.black.withOpacity(0.0),
                        ],
                      ),
                    ),
                  ),
                ),
                Positioned(
                  bottom: 15,
                  left: 10,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(city,
                          style: const TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                              fontWeight: FontWeight.bold)),
                      Text(place['country']!,
                          style: const TextStyle(
                              color: Colors.white70, fontSize: 12)),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

}