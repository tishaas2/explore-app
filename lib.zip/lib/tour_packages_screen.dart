import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'booking_screen.dart';

class TourPackagesScreen extends StatefulWidget {
  @override
  _TourPackagesScreenState createState() => _TourPackagesScreenState();
}

class _TourPackagesScreenState extends State<TourPackagesScreen> {
  List<Map<String, dynamic>> packages = [];

  @override
  void initState() {
    super.initState();
    fetchPackages();
  }

  Future<void> fetchPackages() async {
    final snapshot = await FirebaseFirestore.instance.collection('tourPackages').get();
    for (var doc in snapshot.docs) {
      print("Fetched doc: ${doc.data()}"); // Add this
    }
    setState(() {
      packages = snapshot.docs.map((doc) => doc.data()).toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Tour Packages')),
      body: packages.isEmpty
          ? const Center(child: CircularProgressIndicator())
          : ListView.builder(
        itemCount: packages.length,
        itemBuilder: (context, index) {
          final pkg = packages[index];
          return TourPackageCard(pkg: pkg);
        },
      ),
    );
  }
}

class TourPackageCard extends StatelessWidget {
  final Map<String, dynamic> pkg;

  const TourPackageCard({Key? key, required this.pkg}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final destination = pkg['destination'] ?? 'Unknown';
    final days = pkg['days'] ?? 0;
    final price = pkg['price'] ?? 0;
    final description = pkg['description'] ?? 'No description available';
    final imageName = pkg['imageName'] ?? 'placeholder.jpg';

    return Card(
      margin: const EdgeInsets.all(10),
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Image from local assets (NOT Firebase URL)
          ClipRRect(
            borderRadius: const BorderRadius.vertical(top: Radius.circular(10)),
            child: Image.asset(
              'assets/images/$imageName',
              width: double.infinity,
              height: 180,
              fit: BoxFit.cover,
              errorBuilder: (context, error, stackTrace) =>
              const Icon(Icons.broken_image, size: 100),
            ),
          ),

          Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  destination,
                  style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 5),
                Text(
                  '$days Days | ₹$price',
                  style: const TextStyle(fontSize: 16, color: Colors.grey),
                ),
                const SizedBox(height: 10),
                Text(
                  description,
                  style: const TextStyle(fontSize: 14),
                ),
                const SizedBox(height: 10),
                Align(
                  alignment: Alignment.centerRight,
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => BookingScreen(package: pkg),
                        ),
                      );
                    },
                    child: const Text("Book Now"),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
