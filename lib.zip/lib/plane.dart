import 'package:flutter/material.dart';

class PlaneListScreen extends StatelessWidget {
  final List<Map<String, String>> planes = [
    {'name': 'Indigo Airlines', 'route': 'Delhi - Mumbai'},
    {'name': 'Air India', 'route': 'Bangalore - Kolkata'}
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Planes List')),
      body: ListView.builder(
        itemCount: planes.length,
        itemBuilder: (context, index) {
          return Card(
            margin: EdgeInsets.all(10),
            child: ListTile(
              title: Text(planes[index]['name']!),
              subtitle: Text(planes[index]['route']!),
            ),
          );
        },
      ),
    );
  }
}

