import 'package:flutter/material.dart';
import 'hotel_list_screen.dart';

class HotelSearchScreen extends StatefulWidget {
  @override
  _HotelSearchScreenState createState() => _HotelSearchScreenState();
}

class _HotelSearchScreenState extends State<HotelSearchScreen> {
  final TextEditingController _cityController = TextEditingController();
  DateTime? _checkInDate;
  DateTime? _checkOutDate;
  int _guests = 1;

  Future<void> _selectDate(BuildContext context, bool isCheckIn) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime.now(),
      lastDate: DateTime(2100),
    );
    if (picked != null) {
      setState(() {
        if (isCheckIn) {
          _checkInDate = picked;
        } else {
          _checkOutDate = picked;
        }
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Search Hotels")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _cityController,
              decoration: InputDecoration(labelText: "City Code (e.g., DEL)"),
            ),
            SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: ElevatedButton(
                    onPressed: () => _selectDate(context, true),
                    child: Text(_checkInDate == null
                        ? "Select Check-in"
                        : "Check-in: ${_checkInDate!.toLocal()}".split(' ')[0]),
                  ),
                ),
                SizedBox(width: 10),
                Expanded(
                  child: ElevatedButton(
                    onPressed: () => _selectDate(context, false),
                    child: Text(_checkOutDate == null
                        ? "Select Check-out"
                        : "Check-out: ${_checkOutDate!.toLocal()}".split(' ')[0]),
                  ),
                ),
              ],
            ),
            SizedBox(height: 10),
            Row(
              children: [
                Text("Guests:"),
                SizedBox(width: 10),
                DropdownButton<int>(
                  value: _guests,
                  onChanged: (newValue) {
                    setState(() {
                      _guests = newValue!;
                    });
                  },
                  items: List.generate(10, (index) => index + 1)
                      .map((num) => DropdownMenuItem<int>(
                    value: num,
                    child: Text(num.toString()),
                  ))
                      .toList(),
                ),
              ],
            ),
            SizedBox(height: 20),

            // 🔥 Here's the button you asked about
            ElevatedButton(
              onPressed: () {
                if (_cityController.text.isNotEmpty &&
                    _checkInDate != null &&
                    _checkOutDate != null) {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => HotelListScreen(
                        city: _cityController.text,
                        checkIn: _checkInDate!,
                        checkOut: _checkOutDate!,
                        guests: _guests, location: '',
                      ),
                    ),
                  );
                } else {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text("Please complete all fields")),
                  );
                }
              },
              child: Text("Search Hotels"),
            ),
          ],
        ),
      ),
    );
  }
}
