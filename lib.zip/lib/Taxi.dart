import 'package:flutter/material.dart';

class TransportListScreen extends StatelessWidget {
  final String transportType;
  TransportListScreen(this.transportType);

  final Map<String, List<Map<String, String>>> transportData = {
    "Plane": [
      {'name': 'Indigo Airlines', 'route': 'Delhi - Mumbai'},
      {'name': 'Air India', 'route': 'Bangalore - Kolkata'}
    ],
    "Train": [
      {'name': 'Rajdhani Express', 'route': 'Delhi - Kolkata'},
      {'name': 'Shatabdi Express', 'route': 'Mumbai - Pune'}
    ],
    "Bus": [
      {'name': 'Volvo AC Bus', 'route': 'Chennai - Hyderabad'},
      {'name': 'State Transport', 'route': 'Bangalore - Goa'}
    ],
    "Taxi": [
      {'name': 'Uber', 'route': 'Available Citywide'},
      {'name': 'Ola', 'route': 'Available Citywide'}
    ],
  };

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('$transportType List')),
      body: ListView.builder(
        itemCount: transportData[transportType]?.length ?? 0,
        itemBuilder: (context, index) {
          return Card(
            margin: EdgeInsets.all(10),
            child: ListTile(
              title: Text(transportData[transportType]![index]['name']!),
              subtitle: Text(transportData[transportType]![index]['route']!),
              leading: Icon(Icons.directions_car), // Adds an icon for taxis
            ),
          );
        },
      ),
    );
  }
}
